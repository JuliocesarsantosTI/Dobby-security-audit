<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

function fsa_render_admin_page() {
    if ( ! current_user_can('manage_options') ) { return; }

    $result_html = '';
    $local_snapshot = null;
    $error = '';

    if ( isset($_POST['fsa_run_audit']) && check_admin_referer('fsa_run_audit_nonce', 'fsa_nonce') ) {
        $local_snapshot = FSA_Scanner::collect_snapshot();
        $analysis = FSA_Scanner::call_fireworks($local_snapshot);
        if ( is_wp_error($analysis) ) {
            $error = $analysis->get_error_message();
        } else {
            $result_html = $analysis;
        }
    }
    ?>
    <div class="wrap fsa-wrap">
        <h1 class="fsa-title">Security Audit</h1>
        <div class="fsa-grid">
            <div class="fsa-card">
                <h2 class="fsa-subtitle">Run Audit</h2>
                <form method="post">
                    <?php wp_nonce_field('fsa_run_audit_nonce', 'fsa_nonce'); ?>
                    <p class="fsa-muted">Press the button to analyze your site and receive a prioritized remediation plan.</p>
                    <p><button class="button button-primary fsa-button" type="submit" name="fsa_run_audit" value="1">Run Audit</button></p>
                </form>
                <?php if ( $error ) : ?>
                    <div class="fsa-alert"><?php echo esc_html($error); ?></div>
                <?php endif; ?>
            </div>
            <div class="fsa-card">
                <h2 class="fsa-subtitle">Settings</h2>
                <form method="post" action="options.php">
                    <?php settings_fields('fsa_settings_group'); do_settings_sections('fsa_settings_group'); ?>
                    <label class="fsa-label" for="fsa_api_key">Fireworks API Key</label>
                    <input class="fsa-input" type="text" id="fsa_api_key" name="fsa_api_key" value="<?php echo esc_attr( get_option('fsa_api_key', '') ); ?>" placeholder="fw_xxx..." />

                    <label class="fsa-label" for="fsa_model">Model</label>
                    <input class="fsa-input" type="text" id="fsa_model" name="fsa_model" value="<?php echo esc_attr( get_option('fsa_model', 'accounts/fireworks/models/llama-v3p1-70b-instruct') ); ?>" />

                    <p><button class="button fsa-button" type="submit">Save</button></p>
                </form>
            </div>
        </div>

        <?php if ( $result_html ) : ?>
            <div class="fsa-report-card">
                <h2 class="fsa-subtitle">Findings and Fixes</h2>
                <div class="fsa-report">
                    <?php echo $result_html; // already sanitized into HTML ?>
                </div>
                <?php if ( $local_snapshot ) : ?>
                    <details class="fsa-details">
                        <summary>Technical Snapshot</summary>
                        <pre class="fsa-pre"><?php echo esc_html( wp_json_encode( $local_snapshot, JSON_PRETTY_PRINT ) ); ?></pre>
                    </details>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    </div>
    <?php
}
