<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

if ( ! class_exists('FSA_Scanner') ) {
class FSA_Scanner {

    public static function collect_snapshot() {
        global $wpdb;
        if ( ! function_exists('get_plugins') ) {
            require_once ABSPATH . 'wp-admin/includes/plugin.php';
        }

        $site = [
            'site_url'           => site_url(),
            'home_url'           => home_url(),
            'is_ssl'             => is_ssl(),
            'wp_version'         => get_bloginfo('version'),
            'php_version'        => PHP_VERSION,
            'mysql_version'      => $wpdb->db_version(),
            'server_software'    => isset($_SERVER['SERVER_SOFTWARE']) ? $_SERVER['SERVER_SOFTWARE'] : '',
            'debug'              => defined('WP_DEBUG') && WP_DEBUG ? true : false,
            'script_debug'       => defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? true : false,
            'env'                => defined('WP_ENVIRONMENT_TYPE') ? WP_ENVIRONMENT_TYPE : 'production',
        ];

        $theme = wp_get_theme();
        $theme_info = [
            'name'        => $theme->get('Name'),
            'version'     => $theme->get('Version'),
            'is_child'    => is_child_theme(),
            'parent'      => is_child_theme() ? wp_get_theme(get_template())->get('Name') : '',
        ];

        $all_plugins = get_plugins();
        $active_plugins = get_option('active_plugins', []);
        $plugin_updates = get_site_transient('update_plugins');
        $plugins = [];
        foreach ($all_plugins as $path => $data) {
            $slug = dirname($path);
            $plugins[] = [
                'name'       => isset($data['Name']) ? $data['Name'] : $slug,
                'version'    => isset($data['Version']) ? $data['Version'] : '',
                'is_active'  => in_array($path, $active_plugins, true),
                'update'     => (isset($plugin_updates->response[$path])) ? $plugin_updates->response[$path]->new_version : '',
            ];
        }

        $admins = get_users(['role' => 'administrator', 'fields' => ['user_login', 'user_email', 'user_registered']]);
        $admin_users = [];
        foreach ($admins as $a) {
            $admin_users[] = [
                'user_login'    => $a->user_login,
                'user_email'    => $a->user_email,
                'user_registered' => $a->user_registered,
            ];
        }

        $checks = [
            'rest_api_enabled'   => self::rest_api_enabled(),
            'anyone_can_register'=> get_option('users_can_register') ? true : false,
            'default_admin_exists' => username_exists('admin') ? true : false,
            'file_edit_enabled'  => ! defined('DISALLOW_FILE_EDIT') || (defined('DISALLOW_FILE_EDIT') && DISALLOW_FILE_EDIT === false),
            'auto_updates_core'  => self::core_auto_updates_enabled(),
            'directory_indexing' => self::directory_indexing_exposed(),
        ];

        $wp_config_path = ABSPATH . 'wp-config.php';
        $wp_config_perms = file_exists($wp_config_path) ? substr(sprintf('%o', fileperms($wp_config_path)), -4) : 'N/A';

        return [
            'timestamp'    => current_time('mysql'),
            'site'         => $site,
            'theme'        => $theme_info,
            'plugins'      => $plugins,
            'admin_users'  => $admin_users,
            'checks'       => $checks,
            'wp_config_perms' => $wp_config_perms,
        ];
    }

    private static function rest_api_enabled() {
        $result = apply_filters('rest_authentication_errors', null);
        return is_wp_error($result) ? false : true;
    }

    private static function core_auto_updates_enabled() {
        if ( defined('WP_AUTO_UPDATE_CORE') && WP_AUTO_UPDATE_CORE ) {
            return true;
        }
        return false;
    }

    private static function directory_indexing_exposed() {
        $uploads = wp_get_upload_dir();
        if ( empty($uploads['baseurl']) ) { return null; }
        $test_url = trailingslashit($uploads['baseurl']);
        return 'unknown';
    }

    public static function call_fireworks($snapshot) {
        $api_key = get_option('fsa_api_key');
        if ( empty($api_key) && defined('FSA_FIREWORKS_API_KEY') ) {
            $api_key = FSA_FIREWORKS_API_KEY;
        }
        $model = get_option('fsa_model', 'accounts/fireworks/models/llama-v3p1-70b-instruct');

        if ( empty($api_key) ) {
            return new WP_Error('fsa_no_key', 'Add your Fireworks API key in Settings below.');
        }

        $endpoint = 'https://api.fireworks.ai/inference/v1/chat/completions';

        $system = 'You are a security analyst. Produce a clear, attractive remediation plan with short sections and headings. Do not use any bullet symbols or visual markers such as asterisks, stars, circles, or unicode bullets. Use natural sentences and short paragraphs. Keep formatting plain HTML paragraphs and headings only.';
        $user = 'Analyze this WordPress site snapshot and give concrete actions and prioritized risks. Explain what the problem is and how to fix it. Snapshot JSON: ' . wp_json_encode($snapshot);

        $body = [
            'model' => $model,
            'messages' => [
                ['role' => 'system', 'content' => $system],
                ['role' => 'user', 'content' => $user],
            ],
            'temperature' => 0.2,
            'max_tokens'  => 900
        ];

        $args = [
            'headers' => [
                'Authorization' => 'Bearer ' . $api_key,
                'Content-Type'  => 'application/json',
            ],
            'body'    => wp_json_encode($body),
            'timeout' => 60,
        ];

        $response = wp_remote_post($endpoint, $args);
        if ( is_wp_error($response) ) {
            return $response;
        }
        $code = wp_remote_retrieve_response_code($response);
        $raw  = wp_remote_retrieve_body($response);
        if ( $code < 200 || $code >= 300 ) {
            return new WP_Error('fsa_bad_status', 'Fireworks API error: ' . $code . ' Body: ' . $raw);
        }
        $json = json_decode($raw, true);
        if ( ! $json || empty($json['choices'][0]['message']['content']) ) {
            return new WP_Error('fsa_bad_json', 'Unexpected API response.');
        }
        $content = $json['choices'][0]['message']['content'];
        $content = self::sanitize_explanation($content);
        return $content;
    }

    private static function sanitize_explanation($text) {
        $text = str_replace(['*', '•', '‣', '◦', '▪', '●', '★', '☆'], '', $text);
        $parts = preg_split("/\n{2,}/", $text);
        $html  = '';
        foreach ($parts as $p) {
            $p = trim($p);
            if ($p === '') continue;
            if ( preg_match('/^(#+\s*)?([A-Z][A-Za-z0-9 \-]{2,})[:]?$/', $p) ) {
                $p = preg_replace('/^#+\s*/', '', $p);
                $html .= '<h3>' . esc_html($p) . '</h3>';
            } else {
                $p = preg_replace("/\n+/", ' ', $p);
                $html .= '<p>' . esc_html($p) . '</p>';
            }
        }
        return $html;
    }
}
}
