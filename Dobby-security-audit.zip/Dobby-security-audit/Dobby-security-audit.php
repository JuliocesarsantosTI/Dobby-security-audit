<?php
/**
 * Plugin Name: Dobby Security Audit
 * Description: Checks your WordPress site, summarizes security risks, and gets a remediation plan via Dobby api.
 * Version: 1.0.0
 * Author: alexunitt
 * License: N
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }



define('FSA_PLUGIN_VERSION', '1.0.0');
define('FSA_PLUGIN_DIR', plugin_dir_path(__FILE__));
define('FSA_PLUGIN_URL', plugin_dir_url(__FILE__));

require_once FSA_PLUGIN_DIR . 'inc/class-fsa-scanner.php';
require_once FSA_PLUGIN_DIR . 'inc/class-fsa-admin-page.php';


function fsa_register_settings() {
    register_setting('fsa_settings_group', 'fsa_api_key', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => defined('FSA_FIREWORKS_API_KEY') ? FSA_FIREWORKS_API_KEY : ''
    ]);
    register_setting('fsa_settings_group', 'fsa_model', [
        'type' => 'string',
        'sanitize_callback' => 'sanitize_text_field',
        'default' => 'accounts/fireworks/models/llama-v3p1-70b-instruct'
    ]);
}
add_action('admin_init', 'fsa_register_settings');


function fsa_add_menu() {
    add_menu_page(
        'Security Audit',
        'Security Audit',
        'manage_options',
        'fsa-security-audit',
        'fsa_render_admin_page',
        'dashicons-shield-alt',
        80
    );
}
add_action('admin_menu', 'fsa_add_menu');


function fsa_admin_assets($hook) {
    if ($hook !== 'toplevel_page_fsa-security-audit') { return; }
    wp_enqueue_style('fsa-admin', FSA_PLUGIN_URL . 'assets/admin.css', [], FSA_PLUGIN_VERSION);
}
add_action('admin_enqueue_scripts', 'fsa_admin_assets');
